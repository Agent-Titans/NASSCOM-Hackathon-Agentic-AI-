# Ticketing Tool Export

This directory contains the standalone Streamlit ticketing tool and required support files.

## Run locally

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the app:
   ```bash
   streamlit run streamlit_app.py
   ```

## Notes

- The app uses tickets.db and creates it automatically on first run.
- Uploaded attachment files are stored in uploads/.
- Update SMTP settings in streamlit_app.py for email notifications.
- Default admin user: admin / admin123
