import sqlite3
import secrets
from datetime import datetime
import hashlib
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

import streamlit as st
from agents.classifier import classify_ticket
from agents.router import route_ticket
from agents.resolver import resolve_ticket
from agents.supervisor import supervise_ticket

DB_PATH = 'tickets.db'

# Email configuration (update these with your settings)
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
SMTP_USERNAME = 'your_email@gmail.com'
SMTP_PASSWORD = 'your_app_password'


def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Users table for authentication
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  email TEXT UNIQUE NOT NULL,
                  password_hash TEXT NOT NULL,
                  role TEXT DEFAULT 'user',
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')

    # Modified tickets table
    c.execute('''CREATE TABLE IF NOT EXISTS tickets
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ticket_number TEXT UNIQUE NOT NULL,
                  user_id INTEGER NOT NULL,
                  title TEXT NOT NULL,
                  description TEXT NOT NULL,
                  classification TEXT,
                  team TEXT,
                  resolution TEXT,
                  status TEXT DEFAULT 'open',
                  priority TEXT DEFAULT 'medium',
                  due_date DATE,
                  notification_email TEXT,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  updated_by INTEGER,
                  FOREIGN KEY (user_id) REFERENCES users (id),
                  FOREIGN KEY (updated_by) REFERENCES users (id))''')

    # Comments table
    c.execute('''CREATE TABLE IF NOT EXISTS comments
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ticket_id INTEGER NOT NULL,
                  user_id INTEGER NOT NULL,
                  comment TEXT NOT NULL,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (ticket_id) REFERENCES tickets (id),
                  FOREIGN KEY (user_id) REFERENCES users (id))''')

    # Attachments table
    c.execute('''CREATE TABLE IF NOT EXISTS attachments
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ticket_id INTEGER NOT NULL,
                  user_id INTEGER NOT NULL,
                  filename TEXT NOT NULL,
                  filepath TEXT NOT NULL,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (ticket_id) REFERENCES tickets (id),
                  FOREIGN KEY (user_id) REFERENCES users (id))''')

    # History table for audit trail
    c.execute('''CREATE TABLE IF NOT EXISTS history
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ticket_id INTEGER NOT NULL,
                  user_id INTEGER NOT NULL,
                  action TEXT NOT NULL,
                  old_value TEXT,
                  new_value TEXT,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (ticket_id) REFERENCES tickets (id),
                  FOREIGN KEY (user_id) REFERENCES users (id))''')

    conn.commit()

    # Create default admin user if it doesn't exist
    c.execute("SELECT 1 FROM users WHERE username = 'admin'")
    if not c.fetchone():
        c.execute("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)",
                  ('admin', 'admin@example.com', hash_password('admin123'), 'admin'))
        conn.commit()

    conn.close()


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def create_user(username, email, password, role='user'):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)",
                  (username, email, hash_password(password), role))
        conn.commit()
        user_id = c.lastrowid
        conn.close()
        return user_id
    except sqlite3.IntegrityError:
        conn.close()
        return None


def authenticate_user(username, password):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id, username, email, role FROM users WHERE username = ? AND password_hash = ?",
              (username, hash_password(password)))
    user = c.fetchone()
    conn.close()
    return user


def get_user_by_id(user_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id, username, email, role FROM users WHERE id = ?", (user_id,))
    user = c.fetchone()
    conn.close()
    return user


def send_email_notification(to_email, subject, body):
    try:
        msg = MIMEMultipart()
        msg['From'] = SMTP_USERNAME
        msg['To'] = to_email
        msg['Subject'] = subject

        msg.attach(MIMEText(body, 'plain'))

        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        text = msg.as_string()
        server.sendmail(SMTP_USERNAME, to_email, text)
        server.quit()
        return True
    except Exception as e:
        print(f"Email sending failed: {e}")
        return False


def save_ticket(user_id, title, description, classification, team, resolution, status='open', priority='medium', due_date=None, notification_email=None):
    ticket_number = generate_ticket_number()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO tickets (ticket_number, user_id, title, description, classification, team, resolution, status, priority, due_date, notification_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
              (ticket_number, user_id, title, description, classification, team, resolution, status, priority, due_date, notification_email))
    ticket_id = c.lastrowid
    conn.commit()
    conn.close()
    return ticket_number, ticket_id


def update_ticket(ticket_id, updates, user_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Get current values for history and notification email
    c.execute("SELECT t.*, u.username FROM tickets t JOIN users u ON t.user_id = u.id WHERE t.id = ?", (ticket_id,))
    old_row = c.fetchone()
    if not old_row:
        conn.close()
        return False

    notification_email = old_row[list(c.description).index('notification_email')]
    ticket_number = old_row[list(c.description).index('ticket_number')]
    ticket_title = old_row[list(c.description).index('title')]

    # Update ticket
    set_clause = ", ".join([f"{key} = ?" for key in updates.keys()] + ["updated_at = CURRENT_TIMESTAMP", "updated_by = ?"])
    values = list(updates.values()) + [user_id]
    c.execute(f"UPDATE tickets SET {set_clause} WHERE id = ?", values)

    # Log history
    for key, new_value in updates.items():
        old_value = old_row[list(c.description).index(key)] if key in [desc[0] for desc in c.description] else None
        if str(old_value) != str(new_value):
            c.execute("INSERT INTO history (ticket_id, user_id, action, old_value, new_value) VALUES (?, ?, ?, ?, ?)",
                      (ticket_id, user_id, f"Updated {key}", str(old_value), str(new_value)))

    conn.commit()
    conn.close()

    # Send email notification
    if notification_email and updates:
        updater = get_user_by_id(user_id)
        subject = f"Ticket #{ticket_number} Updated"
        body = f"""
        Your ticket has been updated.

        Ticket: #{ticket_number} - {ticket_title}
        Updated by: {updater[1] if updater else 'Unknown'}

        Changes:
        """
        for key, value in updates.items():
            body += f"- {key}: {value}\n"

        body += "\nYou can view your ticket at: http://localhost:8501"
        send_email_notification(notification_email, subject, body)

    return True


def add_comment(ticket_id, user_id, comment):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO comments (ticket_id, user_id, comment) VALUES (?, ?, ?)",
              (ticket_id, user_id, comment))

    # Get ticket details and notification email
    c.execute("SELECT t.ticket_number, t.title, t.notification_email, u.username FROM tickets t JOIN users u ON t.user_id = u.id WHERE t.id = ?", (ticket_id,))
    ticket_info = c.fetchone()

    conn.commit()
    conn.close()

    # Send email notification
    if ticket_info and ticket_info[2]:  # notification_email exists
        commenter = get_user_by_id(user_id)
        subject = f"New Comment on Ticket #{ticket_info[0]}"
        body = f"""
        A new comment has been added to your ticket.

        Ticket: #{ticket_info[0]} - {ticket_info[1]}
        Comment by: {commenter[1] if commenter else 'Unknown'}
        Comment: {comment}

        You can view your ticket at: http://localhost:8501
        """
        send_email_notification(ticket_info[2], subject, body)


def get_comments(ticket_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT c.comment, c.created_at, u.username
        FROM comments c
        JOIN users u ON c.user_id = u.id
        WHERE c.ticket_id = ?
        ORDER BY c.created_at ASC
    """, (ticket_id,))
    comments = c.fetchall()
    conn.close()
    return [{'comment': r[0], 'created_at': r[1], 'username': r[2]} for r in comments]


def save_attachment(ticket_id, user_id, filename, file_data):
    # Create uploads directory if it doesn't exist
    upload_dir = 'uploads'
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)

    filepath = os.path.join(upload_dir, f"{ticket_id}_{secrets.token_hex(8)}_{filename}")
    with open(filepath, 'wb') as f:
        f.write(file_data)

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO attachments (ticket_id, user_id, filename, filepath) VALUES (?, ?, ?, ?)",
              (ticket_id, user_id, filename, filepath))
    conn.commit()
    conn.close()


def get_attachments(ticket_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT a.filename, a.filepath, a.created_at, u.username
        FROM attachments a
        JOIN users u ON a.user_id = u.id
        WHERE a.ticket_id = ?
        ORDER BY a.created_at DESC
    """, (ticket_id,))
    attachments = c.fetchall()
    conn.close()
    return [{'filename': r[0], 'filepath': r[1], 'created_at': r[2], 'username': r[3]} for r in attachments]


def get_ticket_summaries(user_id=None, filters=None):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    query = """
        SELECT t.ticket_number, t.title, t.created_at, t.status, t.priority, t.due_date, u.username
        FROM tickets t
        JOIN users u ON t.user_id = u.id
    """
    params = []

    conditions = []
    if user_id:
        conditions.append("t.user_id = ?")
        params.append(user_id)

    if filters:
        if 'status' in filters and filters['status']:
            conditions.append("t.status = ?")
            params.append(filters['status'])
        if 'team' in filters and filters['team']:
            conditions.append("t.team = ?")
            params.append(filters['team'])
        if 'priority' in filters and filters['priority']:
            conditions.append("t.priority = ?")
            params.append(filters['priority'])
        if 'search' in filters and filters['search']:
            conditions.append("(t.title LIKE ? OR t.description LIKE ? OR t.ticket_number LIKE ?)")
            search_term = f"%{filters['search']}%"
            params.extend([search_term, search_term, search_term])

    if conditions:
        query += " WHERE " + " AND ".join(conditions)

    query += " ORDER BY t.created_at DESC"

    c.execute(query, params)
    rows = c.fetchall()
    conn.close()
    return [{'ticket_number': r[0], 'title': r[1], 'created_at': r[2], 'status': r[3], 'priority': r[4], 'due_date': r[5], 'username': r[6]} for r in rows]


def get_ticket_detail(ticket_number, user_id=None):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    query = """
        SELECT t.id, t.ticket_number, t.user_id, t.title, t.description, t.classification,
               t.team, t.resolution, t.status, t.priority, t.due_date, t.notification_email, t.created_at, t.updated_at,
               u.username, updater.username as updated_by_name
        FROM tickets t
        JOIN users u ON t.user_id = u.id
        LEFT JOIN users updater ON t.updated_by = updater.id
        WHERE t.ticket_number = ?
    """
    params = [ticket_number]
    if user_id:
        query += " AND t.user_id = ?"
        params.append(user_id)

    c.execute(query, params)
    row = c.fetchone()
    conn.close()
    if not row:
        return None
    return {
        'id': row[0],
        'ticket_number': row[1],
        'user_id': row[2],
        'title': row[3],
        'description': row[4],
        'classification': row[5],
        'team': row[6],
        'resolution': row[7],
        'status': row[8],
        'priority': row[9],
        'due_date': row[10],
        'notification_email': row[11],
        'created_at': row[12],
        'updated_at': row[13],
        'username': row[14],
        'updated_by_name': row[15]
    }


def submit_ticket(user_id, title, description, priority='medium', due_date=None, notification_email=None):
    classification = classify_ticket(description)
    team = route_ticket(classification)
    resolution = resolve_ticket(description, classification)
    status = supervise_ticket(team, resolution, classification)
    ticket_number, ticket_id = save_ticket(user_id, title, description, classification, team, resolution, status, priority, due_date, notification_email)

    # Send email notification
    if notification_email:
        subject = f"Ticket #{ticket_number} Created - {title}"
        body = f"""
        Your ticket has been created successfully.

        Ticket Details:
        - Number: {ticket_number}
        - Title: {title}
        - Priority: {priority}
        - Assigned Team: {team}
        - Status: {status}

        Issue Description: {description}

        Resolution: {resolution}

        You can view your ticket at: http://localhost:8501
        """
        send_email_notification(notification_email, subject, body)

    return {
        'success': True,
        'ticket_number': ticket_number,
        'ticket_id': ticket_id,
        'title': title,
        'description': description,
        'classification': classification,
        'team': team,
        'resolution': resolution,
        'status': status,
        'priority': priority,
        'due_date': due_date,
        'notification_email': notification_email
    }


st.set_page_config(page_title='AI Ticketing Dashboard', layout='wide', page_icon='🎟️')
init_db()

st.markdown(
    """
    <style>
    :root {
        color-scheme: light;
        font-family: 'Roboto', 'Segoe UI', sans-serif;
    }
    html, body, .stApp, .block-container, .main {
        background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 50%, #cbd5e1 100%) !important;
        color: #1a202c !important;
        min-height: 100vh;
    }
    .stApp {
        background: transparent !important;
    }
    .stAppHeader {
        display: none !important;
    }
    .block-container {
        padding-top: 1.5rem !important;
        padding-bottom: 1.5rem !important;
        padding-left: 1.5rem !important;
        padding-right: 1.5rem !important;
        max-width: 1400px;
    }
    .card, .hero-card, .metric-card, .ticket-card, .summary-card {
        border-radius: 16px;
        background: rgba(255, 255, 255, 0.95) !important;
        backdrop-filter: blur(12px);
        border: 1px solid rgba(148, 163, 184, 0.3);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        color: #1a202c !important;
    }
    .hero-card {
        padding: 24px;
        margin-bottom: 16px;
        background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%) !important;
        color: white !important;
    }
    .page-title {
        margin: 0;
        font-size: 2.5rem;
        font-weight: 700;
        letter-spacing: -0.02em;
        line-height: 1.1;
        color: #1a202c !important;
    }
    .page-subtitle {
        margin: 0.5rem 0 0;
        color: rgba(255, 255, 255, 0.9);
        font-size: 1.1rem;
        max-width: 600px;
        line-height: 1.5;
    }
    .summary-card {
        padding: 20px;
        min-height: 140px;
    }
    .summary-title {
        font-size: 1rem;
        color: #2563eb !important;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        margin-bottom: 0.5rem;
        font-weight: 700 !important;
    }
    .summary-text {
        margin: 0;
        color: #1a202c !important;
        font-size: 1rem;
        line-height: 1.6;
        font-weight: 500;
    }
    .metric-card {
        padding: 20px;
        display: grid;
        gap: 0.5rem;
        min-height: 140px;
        text-align: center;
    }
    .metric-card strong {
        font-size: 0.9rem;
        color: #2563eb !important;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        font-weight: 700 !important;
    }
    .metric-value {
        font-size: 2.5rem;
        font-weight: 800;
        color: #1a202c !important;
        line-height: 1;
    }
    .ticket-card {
        padding: 20px;
        margin-bottom: 12px;
    }
    .ticket-link {
        color: #2563eb !important;
        font-weight: 700 !important;
        text-decoration: none;
    }
    .ticket-link:hover {
        color: #1d4ed8;
    }
    .stButton>button {
        background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%) !important;
        color: #ffffff !important;
        border: none !important;
        font-weight: 600 !important;
        box-shadow: 0 4px 16px rgba(59, 130, 246, 0.3) !important;
        padding: 0.75rem 1.5rem !important;
        border-radius: 8px !important;
    }
    .stButton>button:hover {
        opacity: 0.9 !important;
        transform: translateY(-1px);
    }
    .stTextInput>div>div>input, .stTextArea>div>div>textarea {
        background: #ffffff !important;
        color: #1a202c !important;
        border: 2px solid #cbd5e1 !important;
        box-shadow: inset 0 1px 4px rgba(0, 0, 0, 0.05);
        border-radius: 8px !important;
    }
    .stTextInput>label, .stTextArea>label, .stSelectbox>label {
        color: #1a202c !important;
        font-weight: 700 !important;
    }
    .stSelectbox>div>div>select {
        background: #ffffff !important;
        color: #1a202c !important;
        border: 2px solid #cbd5e1 !important;
        border-radius: 8px !important;
    }
    .stDateInput>div>div>input {
        background: #ffffff !important;
        color: #1a202c !important;
        border: 2px solid #cbd5e1 !important;
        border-radius: 8px !important;
    }
    .stDateInput>label, .stFileUploader>label {
        color: #1a202c !important;
        font-weight: 700 !important;
        font-size: 0.95rem !important;
    }
    .stDateInput label, .stFileUploader label {
        color: #1a202c !important;
        font-weight: 700 !important;
    }
    h1, h2, h3, h4, h5, h6 {
        color: #1a202c !important;
        font-weight: 700 !important;
    }
    .stSubheader {
        color: #1a202c !important;
        font-weight: 700 !important;
    }
    .stMarkdown {
        color: #1a202c !important;
    }
    .stTabs [data-baseweb="tab-list"] {
        color: #1a202c !important;
    }
    .stTabs [data-baseweb="tab"] {
        color: #1a202c !important;
        font-weight: 600 !important;
    }
    .stForm {
        background: transparent !important;
    }
    /* Form container text */
    .css-1q1n0ol, .css-1iyw2u5, .css-hxt7ib {
        color: #1a202c !important;
    }
    /* Sidebar text */
    [data-testid="stSidebar"] {
        color: #1a202c !important;
        background: #ffffff !important;
    }
    [data-testid="stSidebar"] * {
        color: #1a202c !important;
    }
    [data-testid="stSidebar"] label {
        color: #1a202c !important;
        font-weight: 700 !important;
    }
    [data-testid="stSidebar"] button {
        color: #1a202c !important;
        font-weight: 600 !important;
    }
    [data-testid="stSidebar"] p {
        color: #1a202c !important;
        font-weight: 600 !important;
    }
    [data-testid="stSidebar"] span {
        color: #1a202c !important;
    }
    [data-testid="stSidebar"] [role="option"] {
        color: #1a202c !important;
    }
    [data-testid="stSidebar"] div {
        color: #1a202c !important;
    }
    .stSelectbox [data-baseweb="select"] {
        color: #1a202c !important;
    }
    /* Ensure all text in sidebar is visible */
    [data-testid="stSidebar"] strong {
        color: #1a202c !important;
        font-weight: 700 !important;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

if 'user' not in st.session_state:
    st.session_state.user = None
if 'selected_ticket' not in st.session_state:
    st.session_state.selected_ticket = None

# Authentication
if st.session_state.user is None:
    st.markdown('<div class="page-title">🎟️ AI Ticketing Dashboard</div>', unsafe_allow_html=True)
    st.markdown('<div class="card">', unsafe_allow_html=True)

    tab1, tab2 = st.tabs(["Login", "Register"])

    with tab1:
        st.subheader("Login")
        with st.form("login_form"):
            login_username = st.text_input("Username")
            login_password = st.text_input("Password", type="password")
            login_submitted = st.form_submit_button("Login")

            if login_submitted:
                user = authenticate_user(login_username, login_password)
                if user:
                    st.session_state.user = user
                    st.success("Login successful!")
                    st.rerun()
                else:
                    st.error("Invalid username or password")

    with tab2:
        st.subheader("Register")
        with st.form("register_form"):
            reg_username = st.text_input("Username")
            reg_email = st.text_input("Email")
            reg_password = st.text_input("Password", type="password")
            reg_confirm = st.text_input("Confirm Password", type="password")
            reg_submitted = st.form_submit_button("Register")

            if reg_submitted:
                if reg_password != reg_confirm:
                    st.error("Passwords do not match")
                elif len(reg_password) < 6:
                    st.error("Password must be at least 6 characters")
                else:
                    user_id = create_user(reg_username, reg_email, reg_password)
                    if user_id:
                        st.success("Registration successful! Please login.")
                    else:
                        st.error("Username or email already exists")

    st.markdown('</div>', unsafe_allow_html=True)

else:
    # Main app for authenticated users
    user = st.session_state.user
    user_id, username, email, role = user

    # Logout button in sidebar
    with st.sidebar:
        st.write(f"Logged in as: **{username}** ({role})")
        if st.button("Logout"):
            st.session_state.user = None
            st.session_state.selected_ticket = None
            st.rerun()

    with st.container():
        total = len(get_ticket_summaries())
        st.markdown(
            f'<div class="page-title">🎟️ AI Ticketing Dashboard</div>',
            unsafe_allow_html=True,
        )

        # Search and filters
        col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
        with col1:
            search_term = st.text_input("Search tickets", placeholder="Search by title, description, or ticket number")
        with col2:
            status_filter = st.selectbox("Status", ["", "open", "in_progress", "resolved", "closed"])
        with col3:
            team_filter = st.selectbox("Team", ["", "support", "development", "billing", "sales"])
        with col4:
            priority_filter = st.selectbox("Priority", ["", "low", "medium", "high", "urgent"])

    filters = {}
    if search_term:
        filters['search'] = search_term
    if status_filter:
        filters['status'] = status_filter
    if team_filter:
        filters['team'] = team_filter
    if priority_filter:
        filters['priority'] = priority_filter

    menu = st.sidebar.selectbox('Navigation', ['Home', 'All Tickets'])

    if menu == 'Home' and not st.session_state.selected_ticket:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        with st.form('ticket_form'):
            st.subheader('Create a new ticket')
            title = st.text_input('Ticket title', placeholder='E.g. Duplicate rows in data file')
            description = st.text_area('Ticket description', placeholder='Describe the problem in detail...')
            priority = st.selectbox('Priority', ['low', 'medium', 'high', 'urgent'], index=1)
            due_date = st.date_input('Due date (optional)', value=None)
            notification_email = st.text_input('Notification email', placeholder='Enter email for updates')
            attachment = st.file_uploader("Attach file (optional)", type=['png', 'jpg', 'jpeg', 'pdf', 'txt', 'doc', 'docx'])
            submitted = st.form_submit_button('Submit ticket')

            if submitted:
                if not title or not description:
                    st.error('Please fill title and description.')
                elif not notification_email:
                    st.error('Please provide a notification email.')
                elif len(description) < 10:
                    st.error('Description must be at least 10 characters.')
                else:
                    with st.spinner('Classifying and generating a response...'):
                        result = submit_ticket(user_id, title, description, priority, due_date, notification_email)
                    st.success(f"Ticket #{result['ticket_number']} created successfully")

                    # Save attachment if provided
                    if attachment:
                        save_attachment(result['ticket_id'], user_id, attachment.name, attachment.getvalue())
                        st.success("Attachment uploaded successfully")

                    st.markdown('---')
                    st.subheader('Ticket summary')
                    st.metric('Assigned team', result['team'])
                    st.write(f"**Category:** {result['classification']}")
                    st.write(f"**Status:** {result['status']}")
                    st.write(f"**Priority:** {result['priority']}")
                    if result['due_date']:
                        st.write(f"**Due date:** {result['due_date']}")
                    st.write(f"**Suggested resolution:** {result['resolution']}")
        st.markdown('</div>', unsafe_allow_html=True)

    elif menu == 'All Tickets' and not st.session_state.selected_ticket:
        summaries = get_ticket_summaries(user_id if role != 'admin' else None, filters)
        if not summaries:
            st.info('No tickets found matching your criteria.')
        else:
            st.write(f"Showing {len(summaries)} tickets")
            ticket_options = [f"{ticket['ticket_number']} | {ticket['title']} | {ticket['status']} | {ticket['priority']}" for ticket in summaries]
            selected_option = st.selectbox('Select a ticket to view', ticket_options)
            if st.button('Open selected ticket'):
                ticket_number = selected_option.split(' | ')[0]
                st.session_state.selected_ticket = ticket_number
                st.rerun()
            st.markdown('---')
            for ticket in summaries[:10]:  # Show first 10
                st.markdown('<div class="ticket-card">', unsafe_allow_html=True)
                st.markdown(f"### {ticket['title']}")
                st.write(f"**Ticket #:** {ticket['ticket_number']}  |  **Status:** {ticket['status']}  |  **Priority:** {ticket['priority']}")
                st.write(f"**Created by:** {ticket['username']}  |  **Created at:** {ticket['created_at']}")
                if ticket['due_date']:
                    st.write(f"**Due date:** {ticket['due_date']}")
                st.markdown('</div>', unsafe_allow_html=True)

    if st.session_state.selected_ticket:
        detail = get_ticket_detail(st.session_state.selected_ticket, user_id if role != 'admin' else None)
        if detail:
            st.markdown('<div class="card">', unsafe_allow_html=True)
            st.markdown(f"# Ticket #{detail['ticket_number']}")
            st.write(f"**Title:** {detail['title']}")
            st.write(f"**Created by:** {detail['username']}")
            st.write(f"**Created at:** {detail['created_at']}")
            st.write(f"**Status:** {detail['status']}")
            st.write(f"**Priority:** {detail['priority']}")
            if detail['due_date']:
                st.write(f"**Due date:** {detail['due_date']}")
            st.write(f"**Category:** {detail['classification']}")
            st.write(f"**Assigned Team:** {detail['team']}")
            st.markdown('---')
            st.subheader('Issue description')
            st.write(detail['description'])
            st.subheader('Resolution')
            st.write(detail['resolution'])

            # Attachments
            attachments = get_attachments(detail['id'])
            if attachments:
                st.subheader('Attachments')
                for att in attachments:
                    st.write(f"📎 {att['filename']} (uploaded by {att['username']} on {att['created_at']})")

            # Comments
            st.subheader('Comments')
            comments = get_comments(detail['id'])
            for comment in comments:
                st.write(f"**{comment['username']}** ({comment['created_at']}): {comment['comment']}")

            # Add comment
            with st.form(f'comment_form_{detail["id"]}'):
                new_comment = st.text_area('Add a comment')
                comment_submitted = st.form_submit_button('Add Comment')
                if comment_submitted and new_comment.strip():
                    add_comment(detail['id'], user_id, new_comment.strip())
                    st.success('Comment added!')
                    st.rerun()

            # Update ticket (for admin or ticket owner)
            if role == 'admin' or detail['user_id'] == user_id:
                st.markdown('---')
                st.subheader('Update Ticket')
                with st.form(f'update_form_{detail["id"]}'):
                    update_status = st.selectbox('Status', ['open', 'in_progress', 'resolved', 'closed'], index=['open', 'in_progress', 'resolved', 'closed'].index(detail['status']))
                    update_priority = st.selectbox('Priority', ['low', 'medium', 'high', 'urgent'], index=['low', 'medium', 'high', 'urgent'].index(detail['priority']))
                    update_team = st.text_input('Assigned Team', value=detail['team'])
                    update_resolution = st.text_area('Resolution', value=detail['resolution'])
                    update_submitted = st.form_submit_button('Update Ticket')

                    if update_submitted:
                        updates = {}
                        if update_status != detail['status']:
                            updates['status'] = update_status
                        if update_priority != detail['priority']:
                            updates['priority'] = update_priority
                        if update_team != detail['team']:
                            updates['team'] = update_team
                        if update_resolution != detail['resolution']:
                            updates['resolution'] = update_resolution

                        if updates:
                            update_ticket(detail['id'], updates, user_id)
                            st.success('Ticket updated successfully!')
                            st.rerun()
                        else:
                            st.info('No changes made.')

            if st.button('Back to tickets'):
                st.session_state.selected_ticket = None
                st.rerun()
            st.markdown('</div>', unsafe_allow_html=True)
        else:
            st.error('Ticket not found or access denied.')
            if st.button('Home'):
                st.session_state.selected_ticket = None
                st.rerun()
