# Resolver Agent
# Uses LLM with similar tickets context to suggest resolutions

import math
import os
import re
import sqlite3
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

# Initialize Groq client
api_key = os.getenv("GROQ_API_KEY", "")
if not api_key:
    print("[RESOLVER] WARNING: GROQ_API_KEY not found in environment. Using fallback resolution.")
    client = None
else:
    print(f"[RESOLVER] GROQ_API_KEY found, initializing Groq client...")
    try:
        client = Groq(api_key=api_key)
        print("[RESOLVER] Groq client initialized successfully.")
    except Exception as e:
        print(f"[RESOLVER] ERROR initializing Groq client: {e}")
        client = None


def tokenize_text(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9 ]+", " ", text)
    tokens = [token for token in text.split() if len(token) > 1]
    return tokens


def build_tfidf(documents):
    tokenized = [tokenize_text(doc) for doc in documents]
    document_count = len(tokenized)

    df = {}
    for tokens in tokenized:
        for token in set(tokens):
            df[token] = df.get(token, 0) + 1

    idf = {token: math.log((document_count + 1) / (df_count + 1)) + 1 for token, df_count in df.items()}

    tfidf_vectors = []
    for tokens in tokenized:
        tf = {}
        total_tokens = len(tokens) or 1
        for token in tokens:
            tf[token] = tf.get(token, 0) + 1
        vector = {token: (count / total_tokens) * idf.get(token, 0) for token, count in tf.items()}
        tfidf_vectors.append(vector)

    return tfidf_vectors


def cosine_similarity(a, b):
    dot = sum(a.get(token, 0) * b.get(token, 0) for token in a)
    mag_a = math.sqrt(sum(value * value for value in a.values()))
    mag_b = math.sqrt(sum(value * value for value in b.values()))
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)


def get_similar_tickets(description, limit=3):
    """
    Find similar resolved tickets from database using semantic similarity.
    """
    try:
        conn = sqlite3.connect('tickets.db')
        c = conn.cursor()
        c.execute("SELECT id, description, classification, resolution FROM tickets WHERE resolution IS NOT NULL AND resolution != 'No similar tickets found.' LIMIT 20")
        tickets = c.fetchall()
        conn.close()

        if not tickets:
            print("Resolver: no prior resolved tickets found.")
            return []

        descriptions = [t[1] for t in tickets] + [description]
        tfidf_vectors = build_tfidf(descriptions)
        query_vector = tfidf_vectors[-1]
        similarities = [cosine_similarity(query_vector, vec) for vec in tfidf_vectors[:-1]]

        ranked = sorted(
            enumerate(similarities),
            key=lambda item: item[1],
            reverse=True
        )

        similar_tickets = [tickets[index] for index, score in ranked if score > 0.2][:limit]
        print(f"Resolver: found {len(similar_tickets)} similar tickets out of {len(tickets)} candidates.")
        return similar_tickets
    except Exception as e:
        print(f"Error fetching similar tickets: {e}")
        return []


def resolve_ticket(description, classification):
    """
    Generate suggested resolution using LLM with context from similar tickets.
    Falls back to keyword-based resolution if LLM unavailable.
    """
    if not client:
        print("Resolver: no Groq client available, using fallback resolution.")
        return resolve_ticket_fallback(description, classification)

    try:
        similar_tickets = get_similar_tickets(description)
        print(f"Resolver: attempting LLM resolution for category '{classification}'.")

        if similar_tickets:
            context = "\nSimilar resolved tickets:\n"
            for ticket in similar_tickets:
                context += f"- Issue: {ticket[1][:120]}\n  Resolution: {ticket[3][:120]}\n"
            prompt = f"""You are a technical support expert. Based on the ticket description and the similar resolved tickets below, provide a concise, actionable resolution that uses the previous solution patterns. Do not mention whether similar tickets were found.

Ticket Category: {classification}
Ticket Description: {description}
{context}
Provide a brief, practical resolution (2-3 sentences max):"""
        else:
            prompt = f"""You are a technical support expert. Based on the ticket description alone, provide a concise, actionable resolution. Do not mention that no past tickets were found.

Ticket Category: {classification}
Ticket Description: {description}
Provide a brief, practical resolution (2-3 sentences max):"""

        if classification == "Database issues":
            prompt = prompt.replace("Provide a brief, practical resolution (2-3 sentences max):", "Include SQL or database-specific troubleshooting steps when appropriate. Provide a brief, practical resolution (2-3 sentences max):")

        message = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            max_tokens=200,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )

        resolution = message.choices[0].message.content.strip()
        print(f"Resolver: LLM returned response length {len(resolution)}.")
        return resolution if resolution else "Unable to generate resolution."
    except Exception as e:
        print(f"Resolution error: {e}")
        return resolve_ticket_fallback(description, classification)


def resolve_ticket_fallback(description, classification):
    """Fallback resolution suggestion based on classification"""
    suggestions = {
        "Network issue": "Check network connectivity, restart router/modem, verify firewall settings, and check DNS resolution.",
        "Data issue": "Verify data integrity, check for corruption, attempt data recovery, and validate sync status.",
        "Database issues": "Review database logs, check query performance, optimize indexes, and validate schema integrity.",
        "Server issues": "Check server logs, verify resources (CPU/memory), restart services, and monitor uptime.",
        "Hardware issues": "Run hardware diagnostics, check physical connections, verify drivers, and monitor temperatures.",
        "Software issues": "Check error logs, update software, clear cache, restart application, and verify dependencies."
    }
    return suggestions.get(classification, "Please contact support for detailed assistance.")