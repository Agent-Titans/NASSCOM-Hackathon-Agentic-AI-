# Classifier Agent
# Uses LLM to intelligently classify tickets

import os
import re
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

# Initialize Groq client
api_key = os.getenv("GROQ_API_KEY", "")
if not api_key:
    print("[CLASSIFIER] WARNING: GROQ_API_KEY not found in environment. Using keyword fallback.")
    client = None
else:
    print(f"[CLASSIFIER] GROQ_API_KEY found, initializing Groq client...")
    try:
        client = Groq(api_key=api_key)
        print("[CLASSIFIER] Groq client initialized successfully.")
    except Exception as e:
        print(f"[CLASSIFIER] ERROR initializing Groq client: {e}")
        client = None

CLASSIFICATIONS = [
    "Network issue",
    "Database issues",
    "Data issue",
    "Server issues",
    "Hardware issues",
    "Software issues"
]

def classify_ticket(description):
    """
    Use LLM to classify ticket into predefined categories.
    Falls back to keyword matching if LLM unavailable.
    """
    if not client:
        return classify_ticket_fallback(description)
    
    try:
        prompt = f"""Classify the following support ticket into ONE of these categories:
{', '.join(CLASSIFICATIONS)}

Ticket Description: {description}

Respond with ONLY the category name, nothing else."""
        
        message = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            max_tokens=100,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        classification = message.choices[0].message.content.strip()
        
        # Validate classification
        if classification in CLASSIFICATIONS:
            return classification
        else:
            return classify_ticket_fallback(description)
    except Exception as e:
        print(f"Classification error: {e}")
        return classify_ticket_fallback(description)

def classify_ticket_fallback(description):
    """Fallback keyword-based classification"""
    description_lower = description.lower()
    
    keywords = {
        "Network issue": ["network", "connection", "wifi", "internet", "connectivity", "ping", "latency"],
        "Database issues": ["database", "db", "query", "sql", "schema", "table", "index"],
        "Data issue": ["data", "corrupt", "missing", "lost", "export", "import", "sync"],
        "Server issues": ["server", "downtime", "crash", "hang", "timeout", "response"],
        "Hardware issues": ["hardware", "disk", "memory", "cpu", "device", "physical"],
        "Software issues": ["software", "bug", "crash", "error", "code", "application", "app"]
    }
    tokens = set(re.findall(r"\b[a-z0-9]+\b", description_lower))
    
    for category, words in keywords.items():
        if any(word in tokens for word in words):
            return category
    
    return CLASSIFICATIONS[0]