# Router Agent
# Assigns team based on classification

def route_ticket(classification):
    teams = {
        "Network issue": "Infrastructure Team",
        "Data issue": "Data Engineering Team",
        "Database issues": "Database Administration Team",
        "Server issues": "Server Operations Team",
        "Hardware issues": "Hardware Support Team",
        "Software issues": "Software Development Team"
    }
    return teams.get(classification, "General Support Team")