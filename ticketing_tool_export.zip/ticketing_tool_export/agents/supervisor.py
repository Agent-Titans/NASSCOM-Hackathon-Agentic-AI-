# Supervisor Agent
# Oversees and assigns to triaging if issues

def supervise_ticket(team, resolution, classification):
    """
    Determine final assignment based on team, resolution quality, and classification.
    """
    # Check if resolution is inadequate
    inadequate_phrases = ["Unable to", "Error generating", "unknown", "unclear"]
    is_inadequate = any(phrase.lower() in resolution.lower() for phrase in inadequate_phrases)
    
    if is_inadequate or team == "General Support Team":
        return "Assigned to Triaging Team for further analysis"
    else:
        return f"Ready for assignment to {team}"